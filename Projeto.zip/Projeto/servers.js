// Importa os módulos necessários
const express = require('express'); // Framework para criar o servidor HTTP
const mysql = require('mysql'); // Biblioteca para conexão com MySQL
const cors = require('cors'); // Middleware para permitir requisições de origens diferentes

const app = express(); // Cria uma instância do Express
app.use(cors()); // Usa o CORS para permitir acesso ao servidor de outros domínios
app.use(express.json()); // Permite o servidor entender dados em JSON no corpo das requisições
app.use(express.static('public')); // Serve arquivos estáticos da pasta 'public'

// Cria a conexão com o banco de dados MySQL
const db = mysql.createConnection({
  host: 'localhost', // Endereço do servidor MySQL
  user: 'root', // Nome de usuário do banco
  password: '', // Senha do banco (deixe em branco se estiver sem senha)
  database: 'loja_db' // Nome do banco de dados
});

// Conecta ao banco de dados
db.connect(err => {
  if (err) throw err; // Se der erro na conexão, lança uma exceção
  console.log('Conectado ao MySQL!'); // Mensagem de sucesso
});

// Rota GET para buscar todos os produtos
app.get('/produtos', (req, res) => {
  db.query('SELECT * FROM produtos', (err, results) => { // Executa consulta SQL para pegar todos os produtos
    if (err) throw err; // Se houver erro, lança exceção
    res.json(results); // Envia os resultados em formato JSON
  });
});

// Rota POST para adicionar um novo produto
app.post('/produtos', (req, res) => {
  const { nome, descricao, preco } = req.body; // Desestrutura os dados recebidos no corpo da requisição
  db.query('INSERT INTO produtos (nome, descricao, preco) VALUES (?, ?, ?)',
    [nome, descricao, preco], // Substitui os ? pelos valores informados
    (err, result) => {
      if (err) throw err; // Se houver erro, lança exceção
      res.json({ id: result.insertId }); // Retorna o ID do novo produto inserido
    });
});

// Define a porta que o servidor vai escutar
const PORT = 3000; // Porta do servidor
app.listen(PORT, () => {
  console.log(`Servidor rodando em http://localhost:${PORT}`); // Mensagem de inicialização
});
